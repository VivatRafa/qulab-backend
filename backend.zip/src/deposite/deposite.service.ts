import { deposite as depositeConfig } from './../config/deposite';
import { createQueryBuilder, Repository } from 'typeorm';
import { Injectable } from '@nestjs/common';
import { CreateDepositeDto } from './dto/create-deposite.dto';
import { UpdateDepositeDto } from './dto/update-deposite.dto';
import { DepositeTariff } from './entities/depositeTariff.entity';
import { Deposite } from './entities/deposite.entity';

@Injectable()
export class DepositeService {
    constructor(private readonly depositeRepository: Repository<Deposite>) {}

    createDeposite(userId: number, amount: number, depositeTariffId: number) {
        const deposite: CreateDepositeDto = {
            user_id: userId,
            date: new Date(),
            amount,
            profit: 0,
            deposite_tariff_id: depositeTariffId,
        };
        this.depositeRepository.save(deposite);
    }

    async updateDepositeAmount() {
        const { MAX_DEPOSITE_PERCENT, MIN_DEPOSITE_PERCENT } = depositeConfig;
        const randomPercent = this.getRandomPercent(MAX_DEPOSITE_PERCENT, MIN_DEPOSITE_PERCENT);

        const depositesList = await this.depositeRepository.find();
        const updateDepositeList = depositesList.forEach((deposite) => {
            const oldAmount = deposite.amount;

            const newAmount = oldAmount * randomPercent;
            const newProfit = deposite.profit + (newAmount - oldAmount);

            const newDeposite: Deposite = {
                ...deposite,
                amount: newAmount,
                profit: newProfit,
            };

            this.depositeRepository.save(newDeposite);
        });
    }

    getRandomPercent(max, min) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min)) + min;
    }
}
