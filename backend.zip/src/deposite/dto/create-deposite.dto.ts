export class CreateDepositeDto {}
