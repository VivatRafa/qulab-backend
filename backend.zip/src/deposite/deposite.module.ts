import { Module } from '@nestjs/common';
import { DepositeService } from './deposite.service';
import { DepositeController } from './deposite.controller';

@Module({
    controllers: [DepositeController],
    providers: [DepositeService],
})
export class DepositeModule {}
