import {
    Controller,
    Get,
    Post,
    Body,
    Patch,
    Param,
    Delete,
} from '@nestjs/common';
import { DepositeService } from './deposite.service';
import { CreateDepositeDto } from './dto/create-deposite.dto';
import { UpdateDepositeDto } from './dto/update-deposite.dto';

@Controller('deposite')
export class DepositeController {
    constructor(private readonly depositeService: DepositeService) {}

    @Post()
    create(@Body() createDepositeDto: CreateDepositeDto) {
        return this.depositeService.create(createDepositeDto);
    }

    @Get()
    findAll() {
        return this.depositeService.findAll();
    }

    @Get(':id')
    findOne(@Param('id') id: string) {
        return this.depositeService.findOne(+id);
    }

    @Patch(':id')
    update(
        @Param('id') id: string,
        @Body() updateDepositeDto: UpdateDepositeDto,
    ) {
        return this.depositeService.update(+id, updateDepositeDto);
    }

    @Delete(':id')
    remove(@Param('id') id: string) {
        return this.depositeService.remove(+id);
    }
}
