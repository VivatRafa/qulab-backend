export const deposite = {
    MAX_DEPOSITE_PERCENT: 1.015,
    MIN_DEPOSITE_PERCENT: 1.035,
};
