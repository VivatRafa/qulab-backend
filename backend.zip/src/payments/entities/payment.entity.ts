import { PaymentActionType } from '../enums/paymentType.enum';
import { User } from './../../users/entities/user.entity';
import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { PaymentActionStatus } from '../enums/paymentStatus.entity';

@Entity()
export class PaymentAction {
    @PrimaryGeneratedColumn()
    id: number;

    @ManyToOne(() => User, (user) => user.id)
    userId: number;

    @Column()
    purseType: number;

    @Column()
    date: Date;

    @Column()
    name: string;

    @Column()
    paymentType: PaymentActionType;

    @Column()
    status: PaymentActionStatus;
}
