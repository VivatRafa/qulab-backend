export enum PaymentActionStatus {
    done,
    inProgress,
    rejected,
}
