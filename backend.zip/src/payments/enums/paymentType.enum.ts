export enum PaymentActionType {
    replenishment,
    withdraw,
}
