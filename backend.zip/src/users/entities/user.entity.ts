import { UserStatus } from './userStatus.entity';
import { Column, Entity, OneToOne, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class User {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    login: string;

    @Column()
    email: string;

    @Column()
    password: string;

    @Column()
    last_aсtivity: Date;

    @Column()
    registration_date: Date;

    @OneToOne(() => UserStatus, (userStatus) => userStatus.id)
    status_id: number;

    @Column({ default: null })
    referral_id?: number;
}
