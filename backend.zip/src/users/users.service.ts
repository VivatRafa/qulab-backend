import { Balance } from './../balance/entities/balance.entity';
import { User } from './entities/user.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';

import { CreateUserDto } from './dto/create-user.dto';
import { Repository } from 'typeorm';
import { UserStatus } from './entities/userStatus.entity';

@Injectable()
export class UsersService {
    basicStatusId: number;

    constructor(
        @InjectRepository(User)
        private readonly userRepository: Repository<User>,
        private readonly balanceRepository: Repository<Balance>,
        private readonly userStatusRepository: Repository<UserStatus>,
    ) {
        this.basicStatusId = 1;
    }

    async createUser(сreateUserDto: CreateUserDto) {
        const newUser: Omit<User, 'id'> = {
            ...сreateUserDto,
            last_aсtivity: new Date(),
            registration_date: new Date(),
            status_id: this.basicStatusId,
        };

        try {
            const user: User = await this.userRepository.save(newUser);
            return user;
        } catch (e) {
            console.log(e);
        }
    }

    async getAllUsers() {
        const users = await this.userRepository.find();
        return users;
    }

    async getUserByEmail(email: string) {
        const user = await this.userRepository.findOne({ where: { email } });
        return user;
    }

    async updateUserStatus(userId: number) {
        const { status_id: currentStatusId } =
            await this.userRepository.findOne({
                where: { user_id: userId },
            });

        const userBalance = await this.balanceRepository.findOne({
            where: { user_id: userId },
        });

        const userStatuses = await this.userStatusRepository.find();

        const currentStatus = userStatuses.find(
            ({ id }) => id === currentStatusId,
        );
        // TODO Как только буду известны числа, можно будет знать как отсортировать неподходящие статусы
        // Нужно выбрать только те статусы, суммы которых больше и выбртаь первую
        const higherUserStatuses = userStatuses.filter(
            ({ id }) => id !== currentStatusId,
        );

        const { id: newStatusId } = higherUserStatuses.find((status) => {
            // const isAmountHighrer = status.amount > currentStatus.amount;
            // const isRefAmountHighrer =
            //     status.ref_amount > currentStatus.ref_amount;
            return status;
        });

        if (!newStatusId) return;

        this.userRepository.update(userId, { status_id: newStatusId });
    }

    async getReferralTree(userId: number) {
        const { status_id: currentStatusId } =
            await this.userRepository.findOne({
                where: { user_id: userId },
            });
    }
}
