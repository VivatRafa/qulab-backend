import { User } from './../../users/entities/user.entity';
import { Column, Entity, PrimaryGeneratedColumn, OneToOne } from 'typeorm';

@Entity()
export class Balance {
    @PrimaryGeneratedColumn()
    id: number;

    @OneToOne(() => User, (user) => user.id)
    user_id: number;

    @Column()
    balance: number;

    @Column()
    invested: number;

    @Column()
    withdrawn: number;

    @Column()
    referral: number;
}
