export class CreateBalanceDto {}
